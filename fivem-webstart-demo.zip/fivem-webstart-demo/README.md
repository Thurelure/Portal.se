# FiveM-webbstart – demo

Det här är en statisk HTML/CSS-demo för en svensk GTA RP/FiveM-community.

## Anpassa innan du visar för en kund
1. Byt "Nordstad RP" till kundens servernamn.
2. Byt färger i `style.css` under `:root`.
3. Byt text och regler så de stämmer med servern.
4. Byt Discord-knappen till kundens riktiga inbjudningslänk.
5. Ta bort ordet DEMO först när sidan är godkänd och allt innehåll är kundens.

## Viktigt
- Detta är bara en frontend-demo. Den har ingen databas, inloggning, betalning eller formulärbackend.
- Samla inte in lösenord, API-nycklar eller personuppgifter med en statisk sida.
- Använd inte kunders logotyper, bilder eller varumärken utan tillstånd.
- GitHub Pages är avsett för projektsidor/portfolio och ska inte användas som gratis hosting för en kommersiell verksamhet. För kundens skarpa webbplats, låt kunden välja och äga sin hosting och sitt konto.
- Om du är under 18: prata med vårdnadshavare innan du tar betalt eller ingår avtal. I Sverige finns särskilda regler för minderåriga företagare.
